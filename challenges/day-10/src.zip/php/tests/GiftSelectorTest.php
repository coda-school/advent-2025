<?php

use Gift\GiftSelector;
use Tests\ChildBuilder;

it('selects first feasible gift for nice child', function () {
    $result = evaluateRequestFor(fn(ChildBuilder $child) => $child->nice()
        ->requestingFeasibleGift('Toy')
        ->requestingFeasibleGift('Book')
    );
    expect($result)->toBe('Toy');
});

it('returns nothing for nice child with only infeasible gifts', function () {
    $result = evaluateRequestFor(fn(ChildBuilder $child) => $child->nice()
        ->requestingInfeasibleGift()
        ->requestingInfeasibleGift()
    );
    expect($result)->toBeNull();
});

it('selects last feasible gift for normal child', function () {
    $result = evaluateRequestFor(fn(ChildBuilder $child) => $child->normal()
        ->requestingFeasibleGift('Toy')
        ->requestingFeasibleGift('PS5')
        ->requestingFeasibleGift('Book')
    );
    expect($result)->toBe('Book');
});

it('returns nothing for normal child with only infeasible gifts', function () {
    $result = evaluateRequestFor(fn(ChildBuilder $child) => $child->normal()
        ->requestingInfeasibleGift('Toy')
        ->requestingInfeasibleGift('Book')
    );
    expect($result)->toBeNull();
});

it('returns nothing for naughty child regardless of gifts', function () {
    $result = evaluateRequestFor(fn(ChildBuilder $child) => $child->naughty()
        ->requestingFeasibleGift('Toy')
    );
    expect($result)->toBeNull();
});

function evaluateRequestFor(callable $childConfiguration): ?string
{
    return GiftSelector::selectGiftFor(
        $childConfiguration(ChildBuilder::aChild())->build()
    );
}