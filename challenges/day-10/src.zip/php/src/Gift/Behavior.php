<?php
declare(strict_types=1);

namespace Gift;


enum Behavior: string
{
    case NAUGHTY = 'naughty';
    case NORMAL = 'normal';
    case NICE = 'nice';
}
