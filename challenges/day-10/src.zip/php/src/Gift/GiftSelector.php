<?php
declare(strict_types=1);

namespace Gift;

class GiftSelector
{
    public static function selectGiftFor(Child $child): ?string
    {
        if ($child->behavior === Behavior::NAUGHTY) {
            return null;
        }

        if ($child->behavior === Behavior::NORMAL) {
            $feasibleGifts = array_filter(
                $child->giftRequests,
                fn(GiftRequest $gift) => $gift->isFeasible
            );
            $giftNames = array_map(
                fn(GiftRequest $gift) => $gift->giftName,
                $feasibleGifts
            );
            if (empty($giftNames)) {
                return null;
            }
            return end($giftNames);
        } else {
            $feasibleGifts = array_filter(
                $child->giftRequests,
                fn(GiftRequest $gift) => $gift->isFeasible
            );
            $giftNames = array_map(
                fn(GiftRequest $gift) => $gift->giftName,
                $feasibleGifts
            );
            if (empty($giftNames)) {
                return null;
            }
            return reset($giftNames);
        }
    }
}
