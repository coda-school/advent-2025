package gift;

public enum Behavior {
    NAUGHTY, NORMAL, NICE
}