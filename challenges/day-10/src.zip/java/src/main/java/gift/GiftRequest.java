package gift;

public record GiftRequest(String giftName, boolean isFeasible) {}