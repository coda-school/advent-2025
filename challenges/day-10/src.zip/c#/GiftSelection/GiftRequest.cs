namespace GiftSelection;

public record GiftRequest(string GiftName, bool IsFeasible);