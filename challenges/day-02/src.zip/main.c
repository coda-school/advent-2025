#include <stdio.h>

int main(void) {
    printf("🎅 Santa: %d out of %d reindeers are present in the stable tonight.\n", 0, 0);
    return 0;
}
