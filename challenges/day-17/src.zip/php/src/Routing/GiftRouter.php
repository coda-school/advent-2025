<?php
declare(strict_types=1);

namespace Routing;

final class GiftRouter
{
    public function route(?Gift $g): string
    {
        if ($g === null) {
            return 'ERROR';
        } else {
            $zone = $g->zone;
            if ($zone === null || trim($zone) === '') {
                return 'WORKSHOP-HOLD';
            } else {
                if ($g->fragile) {
                    if ($g->weightKg <= 2.0) {
                        return 'REINDEER-EXPRESS';
                    } else {
                        return 'SLED';
                    }
                } else {
                    if ($g->weightKg > 10.0) {
                        return 'SLED';
                    } else {
                        if ($zone === 'EU' || $zone === 'NA') {
                            return 'REINDEER-EXPRESS';
                        } else {
                            return 'SLED';
                        }
                    }
                }
            }
        }
    }
}