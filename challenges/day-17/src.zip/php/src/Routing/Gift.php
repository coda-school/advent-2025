<?php
declare(strict_types=1);

namespace Routing;

final class Gift
{
    public function __construct(
        public readonly float $weightKg,
        public readonly bool $fragile,
        public readonly ?string $zone
    ) {}

    public function __toString(): string
    {
        return "Gift{w={$this->weightKg}, fragile={$this->fragile}, zone='{$this->zone}'}";
    }
}