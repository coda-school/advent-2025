package routing;

public class GiftRouter {
    public String route(Gift g) {
        if (g == null) {
            return "ERROR";
        } else {
            String zone = g.zone();
            if (zone == null || zone.isBlank()) {
                return "WORKSHOP-HOLD";
            } else {
                if (g.fragile()) {
                    if (g.weightKg() <= 2.0) {
                        return "REINDEER-EXPRESS";
                    } else {
                        return "SLED";
                    }
                } else {
                    if (g.weightKg() > 10.0) {
                        return "SLED";
                    } else {
                        if ("EU".equals(zone) || "NA".equals(zone)) {
                            return "REINDEER-EXPRESS";
                        } else {
                            return "SLED";
                        }
                    }
                }
            }
        }
    }
}