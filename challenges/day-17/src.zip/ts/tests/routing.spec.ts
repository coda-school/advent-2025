import {GiftRouter} from "../src/giftRouter";

const router = new GiftRouter();

describe('GiftRouter', () => {
    test('Null gift -> ERROR', () => {
        expect(router.route(null))
            .toBe('ERROR');
    });

    describe('Empty/blank zone -> WORKSHOP-HOLD', () => {
        test.each<[string | null | undefined]>([
            [null],
            [undefined],
            [''],
            [' '],
            ['   '],
            ['\t'],
        ])('zone=%p -> WORKSHOP-HOLD', (zone) => {
            expect(router.route({weightKg: 1.0, fragile: false, zone}))
                .toBe('WORKSHOP-HOLD');
        });
    });

    describe('Routing matrix (no null/blank zone)', () => {
        test.each<[number, boolean, string, string]>([
            [2.0,  true,  'EU',   'REINDEER-EXPRESS'],
            [2.1,  true,  'EU',   'SLED'],
            [10.1, false, 'EU',   'SLED'],
            [9.9,  false, 'EU',   'REINDEER-EXPRESS'],
            [9.9,  false, 'NA',   'REINDEER-EXPRESS'],
            [9.9,  false, 'APAC', 'SLED'],
        ])('w=%d, fragile=%p, zone=%s -> %s', (weightKg, fragile, zone, expected) => {
            expect(router.route({weightKg, fragile, zone}))
                .toBe(expected);
        });
    });
});
