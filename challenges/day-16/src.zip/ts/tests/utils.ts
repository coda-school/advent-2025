import * as fs from "node:fs";
import * as path from "node:path";

export function loadFile(fileName: string): string {
    const filePath = path.resolve(__dirname, 'resources', fileName);
    return fs.readFileSync(filePath, 'utf-8');
}