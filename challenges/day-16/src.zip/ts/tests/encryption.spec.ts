import {loadFile} from "./utils";
import {Encryption} from "../src/encryption";
import * as Console from "node:console";

describe('Encryption', () => {
    let encryption: Encryption;

    beforeAll(() => {
        const key = '???';
        const iv = '???';
        encryption = new Encryption(key, iv);
    });

    test('decrypt email', () => {
        const decryptedContent = encryption.decrypt(loadFile('email'));
        expect(decryptedContent != "").toBeTruthy();
        Console.log(decryptedContent);
    });
});