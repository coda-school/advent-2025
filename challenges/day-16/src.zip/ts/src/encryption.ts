import * as crypto from 'crypto';

export class Encryption {
    constructor(key: string, iv: string) {

    }

    decrypt(encryptedText: string): string {
        return '';
    }
}