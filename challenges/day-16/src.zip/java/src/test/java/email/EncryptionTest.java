package email;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class EncryptionTest {
    private final Encryption encryption = new Encryption(
            new Configuration("???", "???")
    );

    @Test
    void decrypt_email() throws Exception {
        var decryptedContent = encryption.decrypt(
                FileUtils.loadFile("encrypted_email")
        );
        assertThat(decryptedContent).isNotBlank();
        System.out.println(decryptedContent);
    }
}
