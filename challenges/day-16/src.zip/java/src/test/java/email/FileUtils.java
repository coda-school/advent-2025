package email;

import java.nio.file.Files;
import java.nio.file.Paths;

public class FileUtils {
    public static String loadFile(String fileName) throws Exception {
        var resource = EncryptionTest.class
                .getClassLoader()
                .getResource(fileName);

        if (resource == null) {
            throw new IllegalArgumentException("File not found: " + fileName);
        }
        return Files.readString(Paths.get(resource.toURI()));
    }

}
