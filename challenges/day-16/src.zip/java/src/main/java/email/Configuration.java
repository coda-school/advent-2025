package email;

public record Configuration(String key, String iv) {
}