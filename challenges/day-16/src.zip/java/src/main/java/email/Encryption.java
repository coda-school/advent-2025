package email;

public record Encryption(Configuration configuration) {
    public String decrypt(String encryptedText) throws Exception {
        return "";
    }
}