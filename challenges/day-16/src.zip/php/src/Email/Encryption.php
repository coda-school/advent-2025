<?php

namespace Email;

use RuntimeException;

class Encryption
{
    private string $key;
    private string $iv;

    public function __construct(string $key, string $iv)
    {

    }

    public function decrypt(string $encryptedText): string
    {
        return "";
    }
}
