<?php

use Email\Encryption;
use Faker\Factory as FakerFactory;
use function PHPUnit\Framework\assertEquals;
use function PHPUnit\Framework\assertNotEmpty;

beforeEach(function () {
    $this->encryption = new Encryption(
        '???',
        '???'
    );
});

test('decrypt the email', function () {
    $decryptedText = $this->encryption->decrypt(
        loadFile('email')
    );
    assertNotEmpty($decryptedText);
    error_log($decryptedText);
});

function loadFile(string $fileName): string
{
    $filePath = __DIR__ . '/resources/' . $fileName;

    if (!file_exists($filePath)) {
        throw new InvalidArgumentException("File not found: $fileName");
    }

    return file_get_contents($filePath);
}