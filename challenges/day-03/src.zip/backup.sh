#!/bin/bash
echo "🔒 Sauvegarde en cours..."
# Sauvegarde la liste des enfants sages dans un coffre-fort sécurisé
sleep 1
echo "🎁 La liste des enfants sages a bien été sauvegardée !"