import {GiftMachine} from "./giftMachine";

async function main() {
    const machine = new GiftMachine();

    const cadeau1 = await machine.createGift("teddy", "Alice");
    console.log(`🎁 Résultat final : ${cadeau1}`);
    console.log("-----------------------------------");

    const cadeau2 = await machine.createGift("book", "Bob");
    console.log(`🎁 Résultat final : ${cadeau2}`);
    console.log("-----------------------------------");

    const cadeau3 = await machine.createGift("robot", "Charlie");
    console.log(`🎁 Résultat final : ${cadeau3}`);
}

main();
