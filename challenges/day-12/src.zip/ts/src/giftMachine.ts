export class GiftMachine {
    public async createGift(type: string, recipient: string): Promise<string> {
        try {
            this.log(`Démarrage de la création du cadeau pour ${recipient}`);

            const gift = this.buildGift(type, recipient);

            await this.wrapGift(gift);
            await this.addRibbon(gift);
            await this.deliverGift(gift, recipient);

            this.log(`Cadeau prêt pour ${recipient} : ${gift}`);
            return gift;
        } catch (error) {
            this.displayError((error as Error).message);
            return `Échec de la création du cadeau pour ${recipient}`;
        }
    }

    private buildGift(type: string, recipient: string): string {
        this.log(`Construction du cadeau de type '${type}'...`);

        switch (type) {
            case "teddy":
                return `🧸 Ourson en peluche pour ${recipient}`;
            case "car":
                return `🚗 Petite voiture pour ${recipient}`;
            case "doll":
                return `🪆 Poupée magique pour ${recipient}`;
            case "book":
                return `📚 Livre enchanté pour ${recipient}`;
            default:
                throw new Error(`Type de cadeau '${type}' non reconnu !`);
        }
    }

    private async wrapGift(gift: string): Promise<void> {
        this.log(`Emballage du cadeau : ${gift}`);
        await this.sleep(3);
    }

    private async addRibbon(gift: string): Promise<void> {
        this.log(`Ajout du ruban magique sur : ${gift}`);
        await this.sleep(2);
    }

    private async deliverGift(gift: string, recipient: string): Promise<void> {
        this.log(`Livraison en cours vers l'atelier de distribution...`);
        await this.sleep(4);

        const chance = Math.floor(Math.random() * 11); // 0 à 10
        if (chance > 8) {
            throw new Error("Erreur de livraison : le traîneau est tombé en panne.");
        }

        this.log(`Cadeau livré à la zone d’expédition pour ${recipient}`);
    }

    private displayError(message: string): void {
        this.log("🚨 ERREUR CRITIQUE 🚨");
        this.log(`❌ ${message}`);
        this.log("🔴 Merci de respecter les principes SOLID");
    }

    private log(message: string): void {
        const time = new Date().toLocaleTimeString();
        console.log(`[${time}] ${message}`);
    }

    private sleep(ms: number): Promise<void> {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}