package gift;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class GiftMachine {
    public String createGift(String type, String recipient) {
        try {
            log("Démarrage de la création du cadeau pour " + recipient);

            String gift = buildGift(type, recipient);

            wrapGift(gift);
            addRibbon(gift);
            deliverGift(gift, recipient);

            log("Cadeau prêt pour " + recipient + " : " + gift);
            return gift;

        } catch (Exception e) {
            displayError(e.getMessage());
            return "Échec de la création du cadeau pour " + recipient;
        }
    }

    private String buildGift(String type, String recipient) throws Exception {
        log("Construction du cadeau de type '" + type + "'...");

        switch (type) {
            case "teddy":
                return "🧸 Ourson en peluche pour " + recipient;
            case "car":
                return "🚗 Petite voiture pour " + recipient;
            case "doll":
                return "🪆 Poupée magique pour " + recipient;
            case "book":
                return "📚 Livre enchanté pour " + recipient;
            default:
                throw new Exception("Type de cadeau '" + type + "' non reconnu !");
        }
    }

    private void wrapGift(String gift) throws InterruptedException {
        log("Emballage du cadeau : " + gift);
        Thread.sleep(3);
    }

    private void addRibbon(String gift) throws InterruptedException {
        log("Ajout du ruban magique sur : " + gift);
        Thread.sleep(2);
    }

    private void deliverGift(String gift, String recipient) throws Exception, InterruptedException {
        log("Livraison en cours vers l'atelier de distribution...");
        Thread.sleep(4);

        Random random = new Random();
        if (random.nextInt(11) > 8) { // 1 chance sur 5 environ
            throw new Exception("Erreur de livraison : le traîneau est tombé en panne.");
        }

        log("Cadeau livré à la zone d’expédition pour " + recipient);
    }

    private void displayError(String message) {
        log("🚨 ERREUR CRITIQUE 🚨");
        log("❌ " + message);
        log("🔴 Merci de respecter les principes SOLID");
    }

    private void log(String message) {
        String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
        System.out.println("[" + time + "] " + message);
    }

    public static void main(String[] args) {
        GiftMachine machine = new GiftMachine();
        String result = machine.createGift("teddy", "Alice");
        System.out.println(result);
    }
}
