package gift;

public class Main {
    public static void main(String[] args) {

        GiftMachine machine = new GiftMachine();

        String cadeau1 = machine.createGift("teddy", "Alice");
        System.out.println("🎁 Résultat final : " + cadeau1);
        System.out.println("-----------------------------------");

        String cadeau2 = machine.createGift("book", "Bob");
        System.out.println("🎁 Résultat final : " + cadeau2);
        System.out.println("-----------------------------------");

        String cadeau3 = machine.createGift("robot", "Charlie");
        System.out.println("🎁 Résultat final : " + cadeau3);
    }
}
