<?php
require_once "Machine.php";

use Gift\Machine;

echo "🎅 Bienvenue à l'atelier du Pôle Nord !\n";
echo "Démarrage de la machine...\n\n";

$machine = new Machine();

$machine->createGift('teddy', 'Alice');
$machine->createGift('car', 'Bob');
$machine->createGift('robot', 'Charlie');
$machine->createGift('doll', 'Diane');
$machine->createGift('book', 'Eliott');