<?php

namespace Gift;

class Machine
{
    public function createGift(string $type, string $recipient): string
    {
        try {
            $this->log("Démarrage de la création du cadeau pour $recipient");

            $gift = $this->buildGift($type, $recipient);

            $this->wrapGift($gift);
            $this->addRibbon($gift);
            $this->deliverGift($gift, $recipient);

            $this->log("Cadeau prêt pour $recipient : $gift");
            return $gift;

        } catch (\Exception $e) {
            $this->displayError($e->getMessage());
            return "Échec de la création du cadeau pour $recipient";
        }
    }

    private function buildGift(string $type, string $recipient): string
    {
        $this->log("Construction du cadeau de type '$type'...");

        if ($type === 'teddy') {
            return "🧸 Ourson en peluche pour $recipient";
        } elseif ($type === 'car') {
            return "🚗 Petite voiture pour $recipient";
        } elseif ($type === 'doll') {
            return "🪆 Poupée magique pour $recipient";
        } elseif ($type === 'book') {
            return "📚 Livre enchanté pour $recipient";
        } else {
            throw new \Exception("Type de cadeau '$type' non reconnu !");
        }
    }

    private function wrapGift(string $gift): void
    {
        $this->log("Emballage du cadeau : $gift");
        usleep(3000); // Petite pause simulée
    }

    private function addRibbon(string $gift): void
    {
        $this->log("Ajout du ruban magique sur : $gift");
        usleep(2000);
    }

    private function deliverGift(string $gift, string $recipient): void
    {
        $this->log("Livraison en cours vers l'atelier de distribution...");
        usleep(4000);

        // Pour l'exercice, nous simulons une erreur avec 1 chance sur 5
        if (rand(0, 10) > 8) {
            throw new \Exception("Erreur de livraison : le traîneau est tombé en panne.");
        }

        $this->log("Cadeau livré à la zone d’expédition pour $recipient");
    }

    private function displayError(string $message): void
    {
        $this->log("🚨 ERREUR CRITIQUE 🚨");
        $this->log("❌ $message");
        $this->log("🔴 Merci de respecter les principes SOLID");
    }

    private function log(string $message): void
    {
        $time = date('H:i:s');
        echo "[$time] $message\n";
    }
}


