namespace Delivery.UseCases
{
    public record DeliverToy(string ChildName, string DesiredToy);
}