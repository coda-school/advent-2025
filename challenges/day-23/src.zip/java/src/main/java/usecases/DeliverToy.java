package usecases;

public record DeliverToy(String childName, String desiredToy) {
}