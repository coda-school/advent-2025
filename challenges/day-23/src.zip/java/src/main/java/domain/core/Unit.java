package domain.core;

public final class Unit {
    public static final Unit DEFAULT = new Unit();

    private Unit() {
    }
}