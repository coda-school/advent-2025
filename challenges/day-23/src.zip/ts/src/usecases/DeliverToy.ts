export class DeliverToy {
    constructor(public childName: string, public desiredToy: string) {
    }
}