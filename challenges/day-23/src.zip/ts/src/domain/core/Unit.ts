export class Unit {
    static default = new Unit();
}