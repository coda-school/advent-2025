export interface IEvent {
    id: string;
    version: number;
    date: Date;
}